const XLSX = require("xlsx");

const parse = (path) => {
  const workbook = XLSX.readFile(path);
  const sheet_name_list = workbook.SheetNames;
  const docs = [];
  sheet_name_list.forEach((sheet) => {
    workbook.Sheets[sheet]["!ref"] = "A1:Z100000";
    const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheet]);
    docs.push({ name: sheet, data: data });
  });
  return docs;
};

function main() {
  const ledgerEntries = parse("./Book2.xlsx");
  console.log(ledgerEntries);
  //console.log(ledgerEntries.map((item) => item.data.map((item) => item.Account)));
}

main();
