const a=[1,2,3,4];
a.push(7);
console.log(a);