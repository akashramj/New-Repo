// var mammoth = require("mammoth");
// var path = require("path");

// var filePath = path.join(__dirname,'./word_source_2.docx');

// mammoth.extractRawText({path: filePath})
//     .then(function(result){
//         var text = result.value; // The raw text

//         //this prints all the data of docx file
//         //console.log(text);
//         console.log('------------------------------');
//         var textLines = text.split ("\n");

//         let data=[];
//         for (var i = 0; i < textLines.length; i++) {
//             //this prints all the data in separate lines
//             //console.log(textLines[i]);
//             data.push(textLines[i]);
//         }
//         console.log(data);
//         var messages = result.messages;
//     })
//     .done();

const WordExtractor = require("word-extractor"); 
const extractor = new WordExtractor();
const extracted = extractor.extract('./word_source_2.docx');

extracted.then(function(doc) { console.log(doc.getBody()); });