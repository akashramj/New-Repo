// const CSVToJSON = require("csvtojson");
// const FileSystem = require("fs");

// CSVToJSON().fromFile("./Book2.csv").then(source => {
//     console.log(source);
// });

const XLSX = require('xlsx');
const workbook = XLSX.readFile('./Book2.xlsx');
const sheetName = workbook.SheetNames[0];
const worksheet = workbook.Sheets[sheetName];
const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 'A' });

console.log(jsonData);

